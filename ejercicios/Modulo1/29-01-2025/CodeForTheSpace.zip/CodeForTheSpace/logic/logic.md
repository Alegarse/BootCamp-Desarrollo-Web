# Visualización en streaming 🎬
---

<div style="width: 50%; height: 300px; background-color: transparent; border: 4px solid black; margin: 0 auto;">
</div>

---
---

<span id="logica-visualización" style="visibility: hidden;">
Hotfix para solventar que al cargar el perfil de usuario, no guarda correctamente las cookies y se relaiza el logout automaticamente al pasar 10 minutos, impidiendo poder ver los videos correctamente.

Cuando se pulse en cada enlace del curso en la pagina "courses", se abrirá el enlace del video de dicho curso en esta pagina "logic", y se
visualizará en el rectángulo habilitado para ello, activandose botones de play, pausa y stop.
Código oculto para solo visualización restánculo video.
Fixeado el problema del inficador de volumen, que no realizaba correctamenet su función, silenciando el sonido en vez de modularlo.
</span>